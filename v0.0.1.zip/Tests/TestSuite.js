var TestSuite;
(function() {
	TestSuite = function() {
		this.table = null;
	}
	
	function runUnitTest(test) {
		try {
			return test();
		} catch(err) {
			return err;
		}
	}
	
	function runPerformanceTest(test) {
		try {
			return test();
		} catch(err) {
			return err;
		}
	}
	
	function getTestResult(suite, test) {
		if (test.slice(0, 9) == "unitTest_") {
			return { type: "Unit Test", name: test.slice(9), result: runUnitTest(suite[test]) };
		} else if (test.slice (0, 16) == "performanceTest_") {
			var retType = { type: "Performance Test", name: test.slice(16), result: runPerformanceTest(suite[test]) };
			if ("_" + test + "_Past") {
				retType.past = suite["_" + test + "_Past"];
			}
			return retType;
		}
		return undefined;
	}
			
	TestSuite.prototype.getTestSuiteResults = function(suite) {
		var results = {};
		if (suite.suiteName != null) {
			results.suiteName = suite.suiteName;
		}
		for(var key in suite) {
			var result = getTestResult(suite, key);
			if (result != null) {
				results[key] = result;
			}
		}
		return results;
	}
	
	TestSuite.prototype.writeTestSuiteResults = function(suite, parentHTMLElement) {
		var table = document.createElement("table");
		parentHTMLElement.appendChild(table);
		if (suite.suiteName != null) {
			var row = document.createElement("tr");
			var column = document.createElement("td");
			column.className = "suiteColumn";
			var value = document.createElement("div");
			value.className = "suite";
			value.appendChild(document.createTextNode(suite.suiteName));
			column.appendChild(value);
			row.appendChild(column);
			table.appendChild(row);
		}
		
		// Get and print results for each test in suite
		for(var key in suite) {
			var result = getTestResult(suite, key);
			if (result != null) {
				// Print Test Type
				var row = document.createElement("tr");
				var column = document.createElement("td");
				column.appendChild(document.createTextNode(result.type));
				row.appendChild(column);
				column = document.createElement("td");
				
				// Print Test Name
				var row = document.createElement("tr");
				var column = document.createElement("td");
				column.appendChild(document.createTextNode(result.name));
				row.appendChild(column);
				column = document.createElement("td");
				
				// Print Current Results
				if (result.result !== "object") {
					var value = document.createElement("div");
					value.className = "result";
					if (result.result === undefined) {
						value.appendChild(document.createTextNode(true));
					} else {
						value.appendChild(document.createTextNode(result.result));
					}
					column.appendChild(value);
				} else {
					var error = result.result;
					var value = document.createElement("div");
					value.className = "result";
					value.appendChild(document.createTextNode(false));
					column.appendChild(value);
					
					if (error.message != null) {
						var message = document.createElement("div");
						message.className = "message";
						message.appendChild(document.createTextNode(error.message));
						column.appendChild(message);
					}
					if (error.stack != null) {
						var stackTrace = document.createElement("div");
						stackTrace.className = "stack";
						var stack = error.stack.split(/(\n|\r)+/);
						for (var key in stack) {
							var value = stack[key].trim();
							if (value.length > 0) {
								var stackLine = document.createElement("div");
								stackLine.appendChild(document.createTextNode(value));
								stackTrace.appendChild(stackLine);
							}
						}
						column.appendChild(stackTrace);
					}
				}
				row.appendChild(column);
				
				// Print Past Results
				if (result.past != null) {
					if (typeof result.past === "number") {
						column = document.createElement("td");
						var value = document.createElement("div");
						if (typeof result.result === "number" && result.result <= result.past) {
							value.className = "past good";
						} else if (typeof result.result === "number" && result.result > result.past) {
							value.className = "past bad";
						}
						value.appendChild(document.createTextNode(result.past));
						column.appendChild(value);
						row.appendChild(column);
					}
				}
				
				// End Line
				table.appendChild(row);
			}
		}
	}
})();