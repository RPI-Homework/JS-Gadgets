var require;
var isLoaded;
var isProcessed;
(function() {
	var map = {};
	var rootDirectory = "file://localhost/D:/Users/Joseph/Websites/Gadgets/v0.0.2/";
	var allFiles = {};
	var allRequests = {};
	
	var loadScript = function(url, callback) {
		// Adding the script tag to the head as suggested before
		var head = document.getElementsByTagName("head")[0];
		var script = document.createElement("script");
		script.type = "text/javascript";
		script.src = url;

		// Then bind the event to the callback function.
		// There are several events for cross browser compatibility.
		script.onreadystatechange = callback;
		script.onload = callback;

		// Fire the loading
		head.appendChild(script);
	}
	
	var createFile = function(fileLocation) {
		var mappedFile = map[fileLocation];
		var realFileLocation = mappedFile ? mappedFile : rootDirectory + fileLocation;
		return {
			id: realFileLocation,
			file: realFileLocation,
			type: "js",
			isRequested: false,
			isLoaded: false,
			requests: []
		};
	}
	
	var getFile = function(fileLocation) {
		var mappedFile = map[fileLocation];
		var realFileLocation = mappedFile ? mappedFile : rootDirectory + fileLocation;
		var file = allFiles[realFileLocation];
		if (file == null) {
			file = createFile(fileLocation);
			allFiles[realFileLocation] = file;
		}
		return file;
	}
	
	var createRequest = function(file) {
		var request = {
			id: file,
			isProcessed: false,
			desiredBy: [],
			requiredBy: [],
			requires: {},
			desires: {}
		};
		if (file != null) {
			request.file = getFile(file);
			request.file.requests.push(request);
		}
		return request;
	}
	
	var getRequest = function(file) {
		if (!file) {
			return createRequest(file);
		} else {
			var request = allRequests[file];
			if (request == null) {
				request = createRequest(file);
				allRequests[file] = request;
			}
			return request;
		}
	}
	
	var loadFile = function(file) {
		// Only load file if it isn't already loading or loaded
		if (file && !file.isRequested) {
			var onFileLoad = function() {
				if (!file.isLoaded) {
					onFileLoaded(file);
					for (var request in file.requests) {
						processRequest(file.requests[request]);
					}
				}
			}
			if (file.type === "js") {
				file.isRequested = true;
				loadScript(file.file, onFileLoad);
			}
		}
	}
	
	var loadRequest = function(request) {
		loadFile(request.file);
	}
	
	var processRequest = function(request) {
		// Only process file if it isn't already processed
		if (request && !request.isProcessed) {
			if (request.onLoad) {
				request.onLoad(request);
			}
			onRequestProcessed(request);
		}
	}
	
	var isRequestRequested = function(request) {
		return !request || !request.file || request.file.isRequested === true;
	}
	
	var isRequestLoaded = function(request) {
		return !request || !request.file || request.file.isLoaded === true;
	}
	
	var isRequestProcessed = function(request) {
		return !request || request.isProcessed === true;
	}
	
	var canProcessRequest = function(request) {
		for (var key1 in request.requires) {
			return false;
		}
		for (var key2 in request.desires) {
			return false;
		}
		return true;
	}
	
	var onFileLoaded = function(file) {
		file.isRequested = true;
		file.isLoaded = true;
		
		// Update all the requests of that file
		for (var request in file.requests) {
			onRequestLoaded(file.requests[request]);
		}
	}
	
	var onRequestLoaded = function(request) {
		if (request.file && request.file.isLoaded !== true) {
			onFileLoaded(request.file);
		} else {
			// Remove request from all file load wait queues
			var desiredBy = request.desiredBy;
			for (var key in desiredBy) {
				// Remove request from file wait queue 
				var desiredBy = desiredBy[key];
				
				// Update the desiry
				delete desiry.desires[request.id];
				
				// If the desiry is not waiting on anything else, process it
				if (canProcessRequest(desiry)) {
					processRequest(desiry);
				}
			}
			
			// Remove load waits as file is already loaded
			delete request.desiredBy;
		}
	}
	
	var onRequestProcessed = function(request) {
		request.isProcessed = true;
		
		// Remove request from all file process wait queues
		var requiredBy = request.requiredBy;
		for (var key in requiredBy) {
			// Remove request from file wait queue 
			var requiry = requiredBy[key];
			
			// Update the requiry
			delete requiry.requires[request.id];
			
			// If the requiry is not waiting on anything else, process it
			if (canProcessRequest(requiry)) {
				processRequest(requiry);
			}
		}
		
		// Remove process waits as file is already processed
		delete request.requiredBy;
	}
	
	isLoaded = function(files) {
		if (typeof files === "array" || typeof files === "object") {
			for (var file in files) {
				if (!isLoaded(files[file])) {
					return false;
				}
			}
			return true;
		} else if (typeof files === "string") {
			if (allRequests[files] != null) {
				return allRequests[files].isLoaded === true;
			}
		}
		return false;
	}
	
	isProcessed = function(files) {
		if (typeof files === "array" || typeof files === "object") {
			for (var file in files) {
				if (!isProcessed(files[file])) {
					return false;
				}
			}
			return true;
		} else if (typeof files === "string") {
			if (allRequests[files] != null) {
				return allRequests[files].isProcessed === true;
			}
		}
		return false;
	}
	
	require = function(parameters) {
		var requests = [];
		var defines = parameters.defines;
		if (typeof defines === "array" || typeof defines === "object") {
			for (var key in defines) {
				var define = defines[key];
				if (typeof define === "string") {
					var request = getRequest(define);
					request.onLoad = parameters.onLoad;
					request.orginalParameters = parameters;
					onRequestLoaded(request);
					requests.push(request);
				}
			}
		} else if (typeof defines === "string") {
			var request = getRequest(define);
			request.onLoad = parameters.onLoad;
			request.orginalParameters = parameters;
			onRequestLoaded(request);
			requests.push(request);
		}
		
		var requestLength = requests.length;
		if (requestLength === 0) {
			// If nothing is defined, but files are required to be loaded
			var request = createRequest(null);
			request.onLoad = parameters.onLoad;
			request.orginalParameters = parameters;
			onRequestLoaded(request);
			requests.push(request);
			requestLength = 1;
		}
		
		// List of everything which needs to be processed
		var requires = parameters.requires;
		if (typeof requires === "array" || typeof requires === "object") {
			for (var key in requires) {
				var requirementFile = requires[key];
				if (typeof requirementFile === "string") {
					var requirement = getRequest(requirementFile);
					if (!isRequestProcessed(requirement)) {
						// Add pre-process requirements
						for (var i = 0; i < requestLength; i++) {
							var request = requests[i];
							request.requires[requirement.id] = requirement;
							requirement.requiredBy.push(request);
						}
						loadRequest(requirement);
					}
				}
			}
		}
		
		// List of everything which needs to be loaded
		var desires = parameters.desires;
		if (typeof desires === "array" || typeof desires === "object") {
			for (var key in desires) {
				var desiredFile = desires[key];
				if (typeof desiredFile === "string") {
					var desire = getRequest(desiredFile);
					if (!isRequestLoaded(desire)) {
						// Add pre-process requirements
						for (var i = 0; i < requestLength; i++) {
							var request = requests[i];
							request.desires[requirement.id] = requirement;
							requirement.desiredBy.push(request);
						}
						loadRequest(requirement);
					}
				}
			}
		}
		
		// List of everything to pre-load
		var includes = parameters.includes;
		if (typeof includes === "array" || typeof includes === "object") {
			for (var key in includes) {
				var includeFile = includes[key];
				if (typeof includeFile === "string") {
					var include = getRequest(includeFile);
					if (!isRequestRequested(include.isRequested)) {
						loadRequest(include);
					}
				}
			}
		}
		
		// Check if all requirements are loaded, then process the file if they are
		for (var i = 0; i < requestLength; i++) {
			var request = requests[i];
			if (canProcessRequest(request)) {
				processRequest(request);
			}
		}
	}
})();